package com.tessera.engine.server.block.construction.BlockTypeModel;

import org.joml.Vector3f;

public class ModelVertex {

    public final Vector3f position = new Vector3f();
    public float u,v;
    public byte normal;
}
